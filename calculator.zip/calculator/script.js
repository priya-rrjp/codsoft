document.addEventListener("DOMContentLoaded", function () {
    const display = document.getElementById("display");
    let currentInput = "";
    let operator = "";
    let prevInput = "";

    // Function to update the display
    function updateDisplay() {
        display.textContent = currentInput;
    }

    // Event listener for number buttons
    const numberButtons = document.querySelectorAll(".number");
    numberButtons.forEach((button) => {
        button.addEventListener("click", function () {
            currentInput += button.value;
            updateDisplay();
        });
    });

    // Event listener for operator buttons
    const operatorButtons = document.querySelectorAll(".operator");
    operatorButtons.forEach((button) => {
        button.addEventListener("click", function () {
            if (currentInput !== "") {
                if (prevInput !== "") {
                    calculateResult();
                }
                operator = button.value;
                prevInput = currentInput;
                currentInput = "";
            }
        });
    });

    // Event listener for the "=" button
    const calculateButton = document.querySelector(".calculate");
    calculateButton.addEventListener("click", calculateResult);

    // Event listener for the "C" button (clear)
    const clearButton = document.querySelector(".clear");
    clearButton.addEventListener("click", function () {
        currentInput = "";
        prevInput = "";
        operator = "";
        updateDisplay();
    });

    // Function to calculate the result
    function calculateResult() {
        if (currentInput !== "") {
            switch (operator) {
                case "+":
                    currentInput = String(parseFloat(prevInput) + parseFloat(currentInput));
                    break;
                case "-":
                    currentInput = String(parseFloat(prevInput) - parseFloat(currentInput));
                    break;
                case "*":
                    currentInput = String(parseFloat(prevInput) * parseFloat(currentInput));
                    break;
                case "/":
                    if (currentInput === "0") {
                        alert("Division by zero is not allowed.");
                        clearButton.click();
                        return;
                    }
                    currentInput = String(parseFloat(prevInput) / parseFloat(currentInput));
                    break;
            }
            prevInput = "";
            operator = "";
            updateDisplay();
        }
    }
});
